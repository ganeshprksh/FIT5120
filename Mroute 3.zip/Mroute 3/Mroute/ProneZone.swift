//
//  ProneZone.swift
//  Mroute
//
//  Created by zhongheng on 4/4/19.
//  Copyright © 2019 Zhongheng Hu. All rights reserved.
//

import Foundation
import MapKit

class ProneZone: NSObject{
    var imageName: String?
    var title: String?
    var longitude: Double?
    var latitude: Double?
    
    init(title: String, longtitude: Double, latitude: Double){
        self.title = title
        self.longitude = longtitude
        self.latitude = latitude
    }
    
}
