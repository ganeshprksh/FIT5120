//
//  AccessibleSpotsViewController.swift
//  Mroute
//
//  Created by zhongheng on 4/4/19.
//  Copyright © 2019 Zhongheng Hu. All rights reserved.
//

import UIKit
import MapKit

class AccessibleSpotsViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {

    @IBOutlet weak var acMap: MKMapView!
    
    var locationManager: CLLocationManager = CLLocationManager()
    var toilet = [Toilets]()
    let regionRadius: CLLocationDistance = 800

    override func viewDidLoad() {
        super.viewDidLoad()
        let initialLocation = CLLocation(latitude: -37.814, longitude: 144.96332)
        //addAnnotation()
        print(toilet.count)
        centerMapOnLocation(location: initialLocation)
        self.locationManager.requestAlwaysAuthorization()
        self.locationManager.requestWhenInUseAuthorization()
        
        if CLLocationManager.locationServicesEnabled(){
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
            locationManager.startUpdatingLocation()
        }
        
        self.acMap.delegate = self
        acMap.mapType = .standard
        acMap.isZoomEnabled = true
        acMap.isScrollEnabled = true
        self.acMap.showsUserLocation = true
        self.acMap.userLocation.title = "Your Current Location"
        locationManager.delegate = self
        
        addAnnotation()
        // Do any additional setup after loading the view.
    }
    
    func mapViewDidFinishLoadingMap(_ mapView: MKMapView) {
        acMap.userTrackingMode = .followWithHeading
    }
    
    func addAnnotation(annotation: MKAnnotation){
        self.acMap.addAnnotation(annotation)
    }
    
    func centerMapOnLocation(location: CLLocation) {
        let coordinateRegion = MKCoordinateRegion(center: location.coordinate,
                                                  latitudinalMeters: regionRadius, longitudinalMeters: regionRadius)
        acMap.setRegion(coordinateRegion, animated: true)
    }
    
    func addAnnotation(){
        for data in toilet {
            let latitude = data.latitude!
            let longitude = data.longitude!
            let name = data.name!
            
            let fenceAnnotation = CLLocationCoordinate2DMake(latitude, longitude)
            let toiletsAnnotation = Annotation(newTitle: name, location: fenceAnnotation)
            
            
            self.acMap.addAnnotation(toiletsAnnotation as MKAnnotation)
            self.acMap.delegate = self
        }
    }

    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        if annotation is MKUserLocation {
            return nil
        }
        
        let annotationView = MKAnnotationView(annotation: annotation, reuseIdentifier: "fenceAnnotation")
        //let anno = annotation as! Annotation
        let resizedSize = CGSize(width: 10, height: 10)
        UIGraphicsBeginImageContext(resizedSize)
        
        annotationView.image = UIImage(named: "toilets")
        annotationView.canShowCallout = true
        annotationView.isEnabled = true
        let btn = UIButton(type: .detailDisclosure)
        annotationView.rightCalloutAccessoryView = btn
        
        return annotationView
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
