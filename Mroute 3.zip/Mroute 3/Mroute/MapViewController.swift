//
//  MapViewController.swift
//  Mroute
//
//  Created by Zhongheng Hu on 30/3/19.
//  Copyright © 2019 Zhongheng Hu. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class MapViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate {

    var locationManager: CLLocationManager = CLLocationManager()
    var til = [Toilets]()
    var proneZ = [ProneZone]()
    
    @IBOutlet weak var zoneMap: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let initialLocation = CLLocation(latitude: -37.814, longitude: 144.96332)
        print(til.count)
        addAnnotation()
        centerMapOnLocation(location: initialLocation)
        self.locationManager.requestAlwaysAuthorization()
        self.locationManager.requestWhenInUseAuthorization()
       
        if CLLocationManager.locationServicesEnabled(){
            locationManager.delegate = self
            locationManager.desiredAccuracy = kCLLocationAccuracyBest
            locationManager.startUpdatingLocation()
        }
        
        self.zoneMap.delegate = self
        zoneMap.mapType = .standard
        zoneMap.isZoomEnabled = true
        zoneMap.isScrollEnabled = true
        self.zoneMap.showsUserLocation = true
        self.zoneMap.userLocation.title = "Your Current Location"
        
        locationManager.delegate = self
        
        centerMapOnLocation(location: initialLocation)
        // Do any additional setup after loading the view.
    }
    
    let regionRadius: CLLocationDistance = 1000

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func mapViewDidFinishLoadingMap(_ mapView: MKMapView) {
        zoneMap.userTrackingMode = .followWithHeading
    }
    
    func addAnnotation(annotation: MKAnnotation){
        self.zoneMap.addAnnotation(annotation)
    }
    
    func centerMapOnLocation(location: CLLocation) {
        let coordinateRegion = MKCoordinateRegion(center: location.coordinate,
                                                  latitudinalMeters: regionRadius, longitudinalMeters: regionRadius)
        zoneMap.setRegion(coordinateRegion, animated: true)
    }
    
    func displayMessage(_ message: String, _ title: String) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: UIAlertController.Style.alert)
        alertController.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
        self.present(alertController, animated: true, completion: nil)
    }
    
    func addAnnotation(){
        for data in proneZ {
            let latitude = data.latitude!
            let longitude = data.longitude!
            let name = data.title!
            
            let fenceAnnotation = CLLocationCoordinate2DMake(latitude, longitude)
            let toiletsAnnotation = Annotation(newTitle: name, location: fenceAnnotation)
            
            
            self.zoneMap.addAnnotation(toiletsAnnotation as MKAnnotation)
            self.zoneMap.delegate = self
        }
    }
    
    func centerMapOnAnnotation(location: CLLocation) {
        let Radius: CLLocationDistance = 30
        let coordinateRegion = MKCoordinateRegion(center: location.coordinate,
                                                  latitudinalMeters: Radius, longitudinalMeters: Radius)
        zoneMap.setRegion(coordinateRegion, animated: true)
    }
    
    
    func focusOn(annotation: MKAnnotation) {
        self.zoneMap.centerCoordinate = annotation.coordinate
        let latitude = annotation.coordinate.latitude
        let longitude = annotation.coordinate.longitude
        let location = CLLocation(latitude: latitude, longitude: longitude)
        self.zoneMap.selectAnnotation(annotation, animated: true)
        centerMapOnAnnotation(location: location)
    }
    
  
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        if annotation is MKUserLocation {
            return nil
        }
        
        let annotationView = MKAnnotationView(annotation: annotation, reuseIdentifier: "fenceAnnotation")
        //let anno = annotation as! Annotation
        let resizedSize = CGSize(width: 10, height: 10)
        UIGraphicsBeginImageContext(resizedSize)
        
        annotationView.image = UIImage(named: "zones")
        annotationView.canShowCallout = true
        annotationView.isEnabled = true
        let btn = UIButton(type: .detailDisclosure)
        annotationView.rightCalloutAccessoryView = btn
        
        return annotationView
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
