//
//  Annotation.swift
//  Mroute
//
//  Created by Zhongheng Hu on 30/3/19.
//  Copyright © 2019 Zhongheng Hu. All rights reserved.
//

import UIKit
import MapKit

class Annotation: NSObject, MKAnnotation {
    var coordinate: CLLocationCoordinate2D
    var title: String?
    var imageName: String?
    
    init(newTitle: String, location: CLLocationCoordinate2D) {
        self.title = newTitle
        self.coordinate = location
    }
}
