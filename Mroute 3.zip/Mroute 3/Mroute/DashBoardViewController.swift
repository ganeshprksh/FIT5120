//
//  DashBoardViewController.swift
//  Mroute
//
//  Created by Zhongheng Hu on 30/3/19.
//  Copyright © 2019 Zhongheng Hu. All rights reserved.
//

import UIKit
import Firebase

class DashBoardViewController: UIViewController {

    
    var ref: DatabaseReference!
    var handle: DatabaseHandle!
    var toilets = [Toilets]()
    var prones = [ProneZone]()
    @IBAction func leadToMapButton(_ sender: Any) {
        
    }
    
    override func viewDidLoad() {
        add()
        addProneZone()
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    

    func add(){
        var toilet = [Toilets]()
        let ref2 = Database.database().reference().child("Toilets")
        ref2.observe(.value , with: { snapshot in 
            if snapshot.childrenCount > 0 || snapshot.childrenCount == 0 {
                for data in snapshot.children.allObjects as! [DataSnapshot]{
                    let object = data.value as? [String: AnyObject]
                    let name = object?["name"] as! String
                    let long = object?["lon"] as! Double
                    let lat = object?["lat"] as! Double
                    let toiletP = Toilets(name: name, longitude: long, latitude: lat)
                    toilet.append(toiletP)
                    
                    //print(name)
                    self.toilets = toilet
                }
            }
        })
    }
    
    func addProneZone(){
        var prone = [ProneZone]()
        let ref2 = Database.database().reference().child("ProneZone")
        ref2.observe(.value , with: { snapshot in
            if snapshot.childrenCount > 0 || snapshot.childrenCount == 0 {
                for data in snapshot.children.allObjects as! [DataSnapshot]{
                    let object = data.value as? [String: AnyObject]
                    let name = object?["ROAD_GEOMETRY"] as! String
                    let long = object?["LONGITUDE"] as! Double
                    let lat = object?["LATITUDE"] as! Double
                    let prone1 = ProneZone(title: name, longtitude: long, latitude: lat)
                    prone.append(prone1)
                    //print(name)
                    self.prones = prone
                }
            }
            //print(prone.count)
        })
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.destination is MapViewController{
            let mc = segue.destination as? MapViewController
            mc?.proneZ = self.prones
        }
        
        if segue.destination is AccessibleSpotsViewController{
            let ac = segue.destination as? AccessibleSpotsViewController
            ac?.toilet = self.toilets
        }
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
